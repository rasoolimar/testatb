<?php
if (!defined('BOT_TOKEN')) define('BOT_TOKEN', '8390747300:AAF0V8Z_Ys3qTuWgKCQHLy4zoxvTxDhYKCg');
