<?php
// Webhook entrypoint
require __DIR__ . '/config.php';
require __DIR__ . '/src/bot.php';
