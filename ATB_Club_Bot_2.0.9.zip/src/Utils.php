<?php
require_once __DIR__ . '/Tg.php';

function to_jalali($timestamp, $format = 'Y/m/d') {
    if (!$timestamp) return '—';
    return date('Y/m/d', $timestamp);
}

function msg_get_photo_file_id($m){
  if(isset($m["photo"]) && is_array($m["photo"]) && count($m["photo"])>0){
    $arr = $m["photo"];
    $last = $arr[count($arr)-1];
    return $last["file_id"] ?? null;
  }
  if(isset($m["document"]["mime_type"]) && strpos($m["document"]["mime_type"],"image/")===0){
    return $m["document"]["file_id"];
  }
  return null;
}
function msg_get_video_file_id($m, &$kind=null){
  $kind=null;
  if(isset($m["video"]["file_id"])) { $kind="video"; return $m["video"]["file_id"]; }
  if(isset($m["animation"]["file_id"])) { $kind="animation"; return $m["animation"]["file_id"]; }
  if(isset($m["document"]["file_id"]) && isset($m["document"]["mime_type"]) && strpos($m["document"]["mime_type"],"video/")===0){
    $kind="document"; return $m["document"]["file_id"];
  }
  return null;
}
function msg_get_any_media_file_id($m, &$kind=null) {
    if ($v = msg_get_video_file_id($m, $k)) { $kind = $k; return $v; }
    if ($p = msg_get_photo_file_id($m)) { $kind = "photo"; return $p; }
    return null;
}

