<?php
require_once __DIR__ . '/Db.php';
require_once __DIR__ . '/Tg.php';

function toolkit_kb($db){
  $buttons = $db['toolkit_buttons'] ?? [];
  if (empty($buttons)) { $buttons = db_default_toolkit_buttons(); $db['toolkit_buttons']=$buttons; db_save($db); }
  $rows = [];
  foreach ($buttons as $idx => $b){
      if (($b['type'] ?? 'url') === 'url') $rows[] = [ ['text' => $b['text'], 'url' => $b['value']] ];
      else $rows[] = [ ['text' => $b['text'], 'callback_data' => 'toolkit_cb:'.$idx] ];
  }
  $rows[] =([ ["text"=>"🧩 پرامپت جادویی CTFC","callback_data"=>"toolkit_ctfc"] ]);
  $rows[] =([ ["text"=>"⬅️ بازگشت به منو","callback_data"=>"back_to_menu"] ]);
  return json_encode(["inline_keyboard"=>$rows], JSON_UNESCAPED_UNICODE);
}

function admin_toolkit_menu($db){
  $rows = [];
  $buttons = $db['toolkit_buttons'] ?? [];
  foreach ($buttons as $i=>$b){
      $rows[] = [ ["text"=>($i+1).". ".$b['text'], "callback_data"=>"tk_edit:".$i] ];
  }
  $rows[] = [ ["text"=>"➕ افزودن","callback_data"=>"tk_add"], ["text"=>"♻️ بازیابی پیش‌فرض","callback_data"=>"tk_reset"] ];
  $rows[] = [ ["text"=>"⬅️ برگشت","callback_data"=>"ap:panel_main"] ];
  return json_encode(["inline_keyboard"=>$rows], JSON_UNESCAPED_UNICODE);
}
