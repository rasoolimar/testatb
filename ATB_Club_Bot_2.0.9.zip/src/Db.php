<?php
require_once __DIR__ . '/../config.php';

function db_default_toolkit_buttons() {
    return [
        ["text"=>"📲 Gemini برای Android","type"=>"url", "value"=>"https://play.google.com/store/apps/details?id=com.google.android.apps.bard"],
        ["text"=>"📲 Gemini برای iOS","type"=>"url", "value"=>"https://apps.apple.com/app/gemini-google-ai/id6477494283"],
        ["text"=>"📲 ChatGPT برای iOS","type"=>"url", "value"=>"https://apps.apple.com/app/openai-chatgpt/id6448311069"],
        ["text"=>"📲 ChatGPT برای Android","type"=>"url", "value"=>"https://play.google.com/store/apps/details?id=com.openai.chatgpt"],
        ["text"=>"🌐 نسخه وب ChatGPT","type"=>"url", "value"=>"https://chat.openai.com/"],
        ["text"=>"🛡️ اکانت VPN یک‌ساله ExpressVPN","type"=>"callback", "value"=>"toolkit_vpn"]
    ];
}
function db_default_free_course() {
    return [
        "id" => 1,
        "title" => "آموزش مقدماتی ATB",
        "description" => "دوره رایگان ۳ مرحله‌ای برای شروع AI",
        "price" => 0,
        "content" => [
            ["type"=>"video","file_id"=>"BAACAgIAAxkBAAIVRGY_T6P0zLftVs7LOKL_1S3t_V5hAAK2PwACjEApSlT6lQ1-yALvNQQ",
             "caption"=>"🎬 ویدئوی ۱ از ۳ ...","exercise_prompt"=>"سه هدف هفته‌ات رو بفرست"],
            ["type"=>"video","file_id"=>"BAACAgIAAxkBAAIVR2Y_T6Sstb8eJcCeG5B2sW3EVbXPAAK3PwACjEApSn3N5P1H-K1JNQQ",
             "caption"=>"🎬 ویدئوی ۲ از ۳ ...","exercise_prompt"=>"اسکرین‌شات گفت‌وگو با ChatGPT را بفرست"],
            ["type"=>"video","file_id"=>"BAACAgIAAxkBAAIVSWY_T6XzC0VwU8x_vHl8AAGi-XW3OQACtT8AAoxAKUqYyT49f2sD5zUE",
             "caption"=>"🎬 ویدئوی ۳ از ۳ ...","exercise_prompt"=>"خروجی پرامپت CTFC را بفرست"]
        ]
    ];
}
function db_default_paid_course() {
    return [
        "id" => 2,
        "title" => "کسب‌وکار بدون سرمایه با AI",
        "description" => "پیدا کردن محصول برنده، ساخت محتوای ویروسی و فروش",
        "price" => 490000,
        "content" => []
    ];
}
function db_initial() {
    return [
      "users" => [],
      "courses" => [db_default_free_course(), db_default_paid_course()],
      "user_courses" => [],
      "subscriptions" => [],
      "pending_exercises" => [],
      "pending_receipts" => [],
      "pending_support_replies" => [],
      "support_open" => [],
      "admin_ids" => [],
      "pending_broadcast" => null,
      "vip_card" => ["file_id" => null],
      "await_set_vip_card" => [],
      "start_media" => ["file_id" => null, "type" => null],
      "await_set_start_media" => [],
      "toolkit_buttons" => db_default_toolkit_buttons(),
      "business_automation_requests" => [],
      "last_reminder_check" => 0,
      "discount_codes" => [],
    ];
}

function db_load(){
  global $DB_FILE;
  if (!file_exists($DB_FILE)) {
    @file_put_contents($DB_FILE, json_encode(db_initial(), JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
  }
  $d = json_decode(@file_get_contents($DB_FILE), true) ?: db_initial();
  // Self-heal missing keys
  $defaults = db_initial();
  foreach ($defaults as $k=>$v) { if (!isset($d[$k])) $d[$k] = $v; }
  return $d;
}
function db_save($db){
  global $DB_FILE;
  $tmp = $DB_FILE.".tmp";
  $json = json_encode($db, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
  $fp = @fopen($tmp, 'c+');
  if ($fp){
    @flock($fp, LOCK_EX);
    @ftruncate($fp, 0);
    @fwrite($fp, $json);
    @fflush($fp);
    @flock($fp, LOCK_UN);
    @fclose($fp);
    @rename($tmp, $DB_FILE);
  } else {
    @file_put_contents($DB_FILE, $json, LOCK_EX);
  }
}
