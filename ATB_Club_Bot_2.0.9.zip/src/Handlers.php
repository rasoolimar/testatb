<?php
require_once __DIR__ . '/Db.php';
require_once __DIR__ . '/Tg.php';
require_once __DIR__ . '/Utils.php';
require_once __DIR__ . '/Ui.php';
require_once __DIR__ . '/Courses.php';
require_once __DIR__ . '/Discounts.php';
require_once __DIR__ . '/Toolkit.php';
require_once __DIR__ . '/Biz.php';
require_once __DIR__ . '/Admin.php';

function user(&$db,$id){
  if(!isset($db["users"][$id])){
    $db["users"][$id]=[
      "state"=>"idle",
      "name"=>null,"phone"=>null,"job"=>null,"ai"=>null,
      "created_at"=>time(),
      "banned"=>false,
      "referrer_id"=>null,
      "referral_balance_usd"=>0,
      "reminder_sent"=>false,
      "biz_auto_form_data" => [],
      "applied_code" => null,
    ];
  }
  return $db["users"][$id];
}

function check_channel_membership($userId) {
    global $PUBLIC_CHANNEL_ID;
    $res = tg_request('getChatMember', ['chat_id' => $PUBLIC_CHANNEL_ID, 'user_id' => $userId]);
    if ($res && ($res['ok'] ?? false)) {
        $status = $res['result']['status'] ?? 'left';
        return in_array($status, ['member', 'administrator', 'creator']);
    }
    return false; // Fail safe
}

function handle_update($update){
  global $SUPPORT_CHAT;
  $db = db_load();
  $msg = $update["message"] ?? null;
  $cb  = $update["callback_query"] ?? null;
  if ($msg){
    $chat = $msg["chat"]["id"]; $fromId = $msg["from"]["id"];
    $text = trim($msg["text"] ?? "");
    $u = user($db, $fromId);

    if (strpos($text, "/start") === 0){
        tg_sendMessage($chat, welcome_text(), main_menu());
        db_save($db); return;
    }

    if ($text === "back" || $text === "بازگشت"){
        tg_sendMessage($chat, "برگشتیم به منو ✅", main_menu()); return;
    }

    if (strpos($u['state'],'biz_')===0){
        biz_handle($db, $u, $chat, $text, $SUPPORT_CHAT); return;
    }

    if (preg_match("/^await_discount_code_(\d+)$/", $u["state"], $m)) {
        $cid = (int)$m[1];
        if ($text and strlen($text) <= 32){
            discount_apply($db, $u, $chat, $cid, $text);
            return;
        } else {
            tg_sendMessage($chat, "اگه کد داری بفرست؛ یا از دکمه پایین بزن که ندارم.", kb([[btn("❌ ندارم، مستقیماً پرداخت کردم","course_no_code:".$cid)]]));
            return;
        }
    }

    if (preg_match("/^await_receipt_(\d+)$/", $u["state"], $m)) {
        $course_id = (int)$m[1];
        $photoId = msg_get_photo_file_id($msg);
        if (!$photoId) { tg_sendMessage($chat, "⚠️ فقط عکس رسید رو بفرست.", kb([[btn("⬅️ بازگشت","paid_courses")]])); return; }
        $u["state"] = "pending_receipt_{$course_id}";
        $mid = $msg["message_id"];
        tg_forwardMessage($SUPPORT_CHAT, $chat, $mid);
        $db["pending_receipts"][] = ["user_id" => $chat, "course_id" => $course_id, "file_id" => $photoId, "orig_mid" => $mid, "time" => time(), "applied_code" => $u['applied_code']];
        $u['applied_code'] = null;
        db_save($db);
        tg_sendMessage($chat, "رسید دریافت شد. بررسی می‌شه 🙏");
        return;
    }

    if (preg_match("/^await_exercise_(\d+)_(\d+)$/", $u["state"], $m)) {
        $course_id = (int)$m[1]; $step = (int)$m[2];
        $u["state"] = "pending_exercise_{$course_id}_{$step}";
        $mid = $msg["message_id"];
        tg_forwardMessage($SUPPORT_CHAT, $chat, $mid);
        $db["pending_exercises"][] = ["user_id"=>$chat, "course_id"=>$course_id, "step"=>$step, "orig_mid"=>$mid, "time"=>time()];
        db_save($db);
        tg_sendMessage($chat, "✅ تمرین رسید. بعد از تایید، مرحله بعد باز می‌شه.");
        return;
    }

    tg_sendMessage($chat, "از منو استفاده کن عزیزم 👇", main_menu());
    return;
  }
  if ($cb){
    $chat = $cb["message"]["chat"]["id"]; $mid = $cb["message"]["message_id"];
    $fromId = $cb["from"]["id"]; $data = $cb["data"];
    $u = user($db, $fromId);

    if ($data==="check_join"){
        if (check_channel_membership($fromId)) tg_editMessageText($chat, $mid, "عالیه! ✅ حالا از منو استفاده کن.", main_menu());
        else tg_answerCb($cb["id"], "هنوز عضویت تایید نشد.");
        return;
    }

    if ($data==="back_to_menu"){ tg_editMessageText($chat, $mid, "منوی اصلی 👇", main_menu()); return; }
    if ($data==="about"){ tg_editMessageText($chat, $mid, about_text(), kb([[btn("⬅️ بازگشت","back_to_menu")]])); return; }
    if ($data==="start_free_course"){
        $prog = $db['user_courses'][$chat][1]['progress'] ?? -1;
        $next = $prog + 1;
        send_course_step($db, $chat, 1, $next);
        return;
    }
    if (strpos($data, "seen_step:")===0){
        list(,$cid,$idx) = explode(":", $data);
        $cid=(int)$cid; $idx=(int)$idx;
        $userProg = $db['user_courses'][$chat][$cid]['progress'] ?? -1;
        if ($idx > $userProg) $db['user_courses'][$chat][$cid]['progress'] = $idx;
        $course = get_course_by_id($db, $cid);
        $step = $course['content'][$idx] ?? [];
        if (!empty($step['exercise_prompt'])){
            $db['users'][$chat]['state'] = "await_exercise_{$cid}_{$idx}";
            db_save($db);
            tg_editMessageText($chat, $mid, $step['exercise_prompt'], kb([[btn("⬅️ بازگشت","back_to_menu")]]));
        } else {
            db_save($db);
            send_course_step($db, $chat, $cid, $idx+1);
        }
        return;
    }
    if ($data==="paid_courses"){
        tg_editMessageText($chat, $mid, "لیست دوره‌ها:", paid_courses_menu($db)); return;
    }
    if (strpos($data,"course_view:")===0){
        $cid = (int)explode(":", $data)[1];
        list($t,$k) = course_view_ui($db, $cid);
        tg_editMessageText($chat, $mid, $t, $k); return;
    }
    if (strpos($data,"course_steps:")===0){
        $cid = (int)explode(":", $data)[1];
        $kb = course_steps_ui($db, $cid);
        tg_editMessageText($chat, $mid, "سرفصل‌ها:", $kb); return;
    }
    if (strpos($data,"course_buy:")===0){
        $cid = (int)explode(":", $data)[1];
        $db['users'][$chat]['state'] = "await_discount_code_{$cid}";
        db_save($db);
        tg_editMessageText($chat, $mid, "اگه کد تخفیف داری بفرست. اگه نداری، عکس رسید پرداخت رو بفرست تا بررسی شه.", kb([[btn("❌ ندارم، مستقیماً پرداخت کردم","course_no_code:".$cid)], [btn("⬅️ بازگشت","course_view:".$cid)]]));
        return;
    }
    if (strpos($data,"course_no_code:")===0){
        $cid = (int)explode(":", $data)[1];
        $db['users'][$chat]['state'] = "await_receipt_{$cid}"; db_save($db);
        tg_editMessageText($chat, $mid, "خب! رسید پرداخت رو همینجا بفرست 🌟", kb([[btn("⬅️ بازگشت","course_view:".$cid)]]));
        return;
    }
    if (strpos($data,"course_gift:")===0){
        $cid = (int)explode(":", $data)[1];
        $db['users'][$chat]['state'] = "await_gift_phone_{$cid}"; db_save($db);
        $hint = "برای هدیه دادن، شماره موبایل شخص رو به یکی از ۳ حالت زیر بفرست:\n• 09xxxxxxxxx\n• +989xxxxxxxxx\n• 9xxxxxxxxx (من تبدیل می‌کنم)";
        tg_editMessageText($chat, $mid, $hint, kb([[btn("⬅️ بازگشت","course_view:".$cid)]]));
        return;
    }
    if ($data==="vip_membership"){
        tg_editMessageText($chat, $mid, "برای VIP، رسید پرداخت پلن رو بفرست. هر سوالی بود پشتیبانی هست.", kb([[btn("⬅️ بازگشت","back_to_menu")]])); return;
    }
    if ($data==="toolkit"){
        tg_editMessageText($chat, $mid, "لینک‌ها و ابزارهای پیشنهادی:", toolkit_kb($db)); return;
    }
    if ($data==="biz_automation_start"){
        biz_start($db, $u, $chat); tg_answerCb($cb["id"], "شروع شد"); return;
    }
    if ($data==="biz_confirm"){ biz_confirm_send($db, $u, $chat, $SUPPORT_CHAT); return; }
    if ($data==="biz_restart"){ biz_start($db, $u, $chat); return; }

    if (is_admin($db, $fromId)){
        if ($data==="ap:panel_main"){
            tg_editMessageText($chat, $mid, admin_panel_text($db), admin_panel_kb()); return;
        }
        if ($data==="ap:manage_toolkit"){
            tg_editMessageText($chat, $mid, "مدیریت ابزارک:", admin_toolkit_menu($db)); return;
        }
        if ($data==="ap:coupons_menu"){
            tg_editMessageText($chat, $mid, "کدهای تخفیف:", admin_coupons_menu($db)); return;
        }
    }

    tg_answerCb($cb["id"], "انجام شد ✅");
  }
}
