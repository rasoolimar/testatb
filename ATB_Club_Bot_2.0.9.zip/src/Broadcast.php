<?php
require_once __DIR__ . '/Db.php';
require_once __DIR__ . '/Tg.php';

function segment_users(&$db, $segment){
    $uids = array_keys($db['users']);
    $out = [];
    $todayStart = strtotime('today');
    foreach ($uids as $uid){
        $u = $db['users'][$uid];
        $hasVip = !empty($db['subscriptions'][$uid]) && ($db['subscriptions'][$uid]['expires_at'] ?? 0) > time();
        $freeProgress = $db['user_courses'][$uid][1]['progress'] ?? -1;
        $created = $u['created_at'] ?? 0;
        switch ($segment){
            case 'all': $ok=true; break;
            case 'vip': $ok=$hasVip; break;
            case 'novip': $ok=!$hasVip; break;
            case 'new_today': $ok=($created >= $todayStart); break;
            case 'free_not_started': $ok=($freeProgress==-1); break;
            case 'free_started': $ok=($freeProgress>=0 && $freeProgress<2); break;
            case 'free_completed': $ok=($freeProgress>=2); break;
            default: $ok=true;
        }
        if ($ok) $out[] = $uid;
    }
    return $out;
}
