<?php
require_once __DIR__ . '/Tg.php';
require_once __DIR__ . '/Db.php';

function welcome_text(){
  return "سلام! 👋\n"
    ."به ربات تخصصی <b>ATB Club</b> خوش اومدی.\n\n"
    ."از منوی زیر شروع کن.";
}
function about_text(){
  global $PUBLIC_CHANNEL_ID;
  return "<b>درباره ATB Club</b>\n\n"
        ."ما اینجاییم تا نشون بدیم AI فقط ترند نیست—واقعاً می‌تونه فروش و سرعتت رو چندبرابر کنه.\n\n"
        ."کانال عمومی: ".$PUBLIC_CHANNEL_ID;
}
function main_menu(){
  return kb([
    [btn("🎓 آموزش مقدماتی رایگان", "start_free_course")],
    [btn("💰 آموزش‌های پولساز", "paid_courses")],
    [btn("👑 اشتراک VIP", "vip_membership")],
    [btn("💡 هوشمندسازی کسب‌وکار", "biz_automation_start")],
    [btn("💵 کسب درآمد دلاری", "referral_menu"), btn("👤 حساب کاربری", "account_menu")],
    [btn("🧰 ابزارک", "toolkit"), btn("❓ سوالات متداول", "faq")],
    [btn("🆘 پشتیبانی", "support_contact"), btn("ℹ️ درباره ما", "about")],
  ]);
}
