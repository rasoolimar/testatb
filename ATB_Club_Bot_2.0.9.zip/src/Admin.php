<?php
require_once __DIR__ . '/Db.php';
require_once __DIR__ . '/Tg.php';
require_once __DIR__ . '/Courses.php';
require_once __DIR__ . '/Toolkit.php';
require_once __DIR__ . '/Discounts.php';

function is_admin(&$db, $userId){
  global $ADMIN_PHONE;
  if(!$userId) return false;
  if(in_array((int)$userId, $db["admin_ids"] ?? [], true)) return true;
  $u = $db["users"][$userId] ?? null;
  if($u){
    $ph = normalize_phone($u["phone"] ?? "");
    if($ph){
      $approved = [];
      if (is_array($ADMIN_PHONE)) { foreach($ADMIN_PHONE as $p){ $approved[] = normalize_phone($p); } }
      else { $approved[] = normalize_phone($ADMIN_PHONE); }
      if (in_array($ph, $approved, true)){
        if(!in_array((int)$userId, $db["admin_ids"] ?? [], true)) { $db["admin_ids"][] = (int)$userId; db_save($db); }
        return true;
      }
    }
  }
  return false;
}

function admin_panel_text(&$db){
    $all = $db["users"] ?? [];
    $total = count($all);
    $todayStart = strtotime('today');
    $today = 0;
    foreach($all as $id=>$uu){ if( (int)($uu["created_at"]??0) >= $todayStart ) $today++; }
    $pendingExCount = count($db["pending_exercises"] ?? []);
    $pendingRecCount = count($db["pending_receipts"] ?? []);
    return "🛠️ <b>پنل مدیریت ATB</b> — نسخه ".ATB_VERSION."\n\n"
           . "👥 کل کاربران: <b>{$total}</b> | امروز: <b>{$today}</b>\n"
           . "⏳ تمرین‌های در صف: <b>{$pendingExCount}</b>\n"
           . "🧾 رسیدهای در صف: <b>{$pendingRecCount}</b>";
}
function admin_panel_kb(){
    return kb([
        [ ["text"=>"🎓 مدیریت دوره رایگان", "callback_data"=>"ap:manage_free_course_menu"], ["text"=>"📚 مدیریت دوره‌ها", "callback_data"=>"ap:manage_courses"] ],
        [ ["text"=>"🎁 کدهای تخفیف","callback_data"=>"ap:coupons_menu"], ["text"=>"🧰 ابزارک", "callback_data"=>"ap:manage_toolkit"] ],
        [ ["text"=>"📢 پیام همگانی","callback_data"=>"ap:broadcast"] ],
    ]);
}

function admin_coupons_menu(&$db){
    $rows = [];
    foreach ($db['discount_codes'] as $code => $c){
        $cap = ($c['type']=='percent' ? ("%".$c['value']) : (number_format($c['value'])." تومان"));
        $limit = isset($c['max_uses']) ? $c['max_uses'] : '∞';
        $rows[] = [ ["text"=>"{$code} — {$cap} | باقی: {$limit}", "callback_data"=>"dc_view:".$code] ];
    }
    $rows[] = [ ["text"=>"➕ اضافه‌کردن کد","callback_data"=>"dc_add"] ];
    $rows[] = [ ["text"=>"⬅️ برگشت","callback_data"=>"ap:panel_main"] ];
    return json_encode(["inline_keyboard"=>$rows], JSON_UNESCAPED_UNICODE);
}
