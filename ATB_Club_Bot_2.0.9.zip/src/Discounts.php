<?php
require_once __DIR__ . '/Db.php';
require_once __DIR__ . '/Tg.php';

function discount_apply(&$db, &$user, $chat, $course_id, $code_text){
    $code_text = strtoupper(trim($code_text));
    $code = $db['discount_codes'][$code_text] ?? null;
    $course = null;
    foreach ($db['courses'] as $c){ if ($c['id']==$course_id) { $course=$c; break; } }
    if (!$code){ tg_sendMessage($chat, "کد تخفیف نامعتبره."); return false; }
    if (!empty($code['course_id']) && $code['course_id'] != $course_id){ tg_sendMessage($chat, "این کد برای این دوره معتبر نیست."); return false; }
    if (isset($code['max_uses']) && $code['max_uses'] <= 0){ tg_sendMessage($chat, "ظرفیت این کد تمام شده."); return false; }
    $price = $course['price'];
    $new_price = $price;
    if (($code['type'] ?? 'percent')==='percent'){ $new_price = max(0, $price - ($price*($code['value'] ?? 0)/100)); }
    else { $new_price = max(0, $price - ($code['value'] ?? 0)); }
    $user['applied_code'] = $code_text;
    db_save($db);
    tg_sendMessage($chat, "✅ کد اعمال شد.\nقیمت جدید: <b>".number_format($new_price)." تومان</b>\nحالا رسید پرداخت رو بفرست.");
    return true;
}

function discount_decrement(&$db, $code_text){
    $code_text = strtoupper($code_text);
    if (!isset($db['discount_codes'][$code_text])) return;
    if (isset($db['discount_codes'][$code_text]['max_uses']) && $db['discount_codes'][$code_text]['max_uses']>0){
        $db['discount_codes'][$code_text]['max_uses'] -= 1;
        db_save($db);
    }
}
