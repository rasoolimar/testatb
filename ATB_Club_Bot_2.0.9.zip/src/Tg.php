<?php
require_once __DIR__ . '/../config.php';

$API = "https://api.telegram.org/bot".$BOT_TOKEN."/";

function log_it($msg){
  global $LOG_FILE;
  @file_put_contents($LOG_FILE, date('c')." | ".$msg.PHP_EOL, FILE_APPEND);
}

function http_post($url, $params){
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => 1,
      CURLOPT_POST => 1,
      CURLOPT_POSTFIELDS => $params,
      CURLOPT_TIMEOUT => 20
    ]);
    $res = curl_exec($ch);
    if ($res === false) { $res = "CURL_ERR: ".curl_error($ch); }
    curl_close($ch); return $res;
  } else {
    $opts = ['http' => [
      'method'  => 'POST',
      'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
      'content' => http_build_query($params),
      'timeout' => 20
    ]];
    return @file_get_contents($url, false, stream_context_create($opts));
  }
}

function tg_request($method, $params) {
    global $API;
    $res = http_post($API . $method, $params);
    log_it("{$method}: " . $res);
    return json_decode($res, true);
}
function kb($rows){ return json_encode(["inline_keyboard"=>$rows], JSON_UNESCAPED_UNICODE); }
function btn($t,$d){ return ["text"=>$t,"callback_data"=>$d]; }
function rkb($rows){ return json_encode(["keyboard"=>$rows,"resize_keyboard"=>true,"one_time_keyboard"=>true], JSON_UNESCAPED_UNICODE); }
function rkb_remove(){ return json_encode(["remove_keyboard" => true], JSON_UNESCAPED_UNICODE); }

function tg_sendMessage($chat,$text,$markup=null){
  $p = ["chat_id"=>$chat,"text"=>$text,"parse_mode"=>"HTML", "disable_web_page_preview"=>true];
  if($markup) $p["reply_markup"]=$markup;
  return tg_request("sendMessage", $p);
}
function tg_editMessageText($chat, $mid, $text, $markup = null) {
    $p = ["chat_id" => $chat, "message_id" => $mid, "text" => $text, "parse_mode" => "HTML", "disable_web_page_preview" => true];
    if ($markup) $p["reply_markup"] = $markup;
    return tg_request("editMessageText", $p);
}
function tg_sendVideo($chat,$src,$cap,$markup=null){
  $p = ["chat_id"=>$chat,"video"=>$src,"caption"=>$cap,"parse_mode"=>"HTML"];
  if($markup) $p["reply_markup"]=$markup;
  return tg_request("sendVideo", $p);
}
function tg_sendPhoto($chat,$url,$cap,$markup=null){
  $p = ["chat_id"=>$chat,"photo"=>$url,"caption"=>$cap,"parse_mode"=>"HTML"];
  if($markup) $p["reply_markup"]=$markup;
  return tg_request("sendPhoto", $p);
}
function tg_forwardMessage($to,$from,$msgId){
  return tg_request("forwardMessage", ["chat_id"=>$to,"from_chat_id"=>$from,"message_id"=>$msgId]);
}
function tg_copyMessage($to, $from, $msgId, $markup = null) {
    $p = ["chat_id" => $to, "from_chat_id" => $from, "message_id" => $msgId];
    if ($markup) $p["reply_markup"] = $markup;
    return tg_request("copyMessage", $p);
}
function tg_answerCb($id,$text=""){
  return tg_request("answerCallbackQuery", ["callback_query_id"=>$id,"text"=>$text]);
}

function normalize_phone($raw){
  $p = preg_replace('~\D+~','',$raw);
  if(strpos($p,'+98')===0) $p = '0'.substr($p,3);
  if(strpos($p,'98')===0)  $p = '0'.substr($p,2);
  if($p && $p[0] !== '0')  $p = '0'.$p;
  return $p;
}
