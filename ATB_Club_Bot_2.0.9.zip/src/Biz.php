<?php
require_once __DIR__ . '/Db.php';
require_once __DIR__ . '/Tg.php';

function biz_start(&$db, &$u, $chat){
    $u['state'] = 'biz_q1';
    $u['biz_auto_form_data'] = [];
    db_save($db);
    tg_sendMessage($chat, "بیاین کسب‌وکارت رو هوشمند کنیم! 😊\n\n1) حوزه کاری‌ت چیه؟ (یک جمله)");
}
function biz_handle(&$db, &$u, $chat, $text, $support_chat){
    $state = $u['state'] ?? 'idle';
    switch($state){
        case 'biz_q1':
            $u['biz_auto_form_data']['industry'] = $text; $u['state']='biz_q2';
            tg_sendMessage($chat, "2) الان بزرگ‌ترین مشکل/گلوگاه چیه؟");
            break;
        case 'biz_q2':
            $u['biz_auto_form_data']['pain'] = $text; $u['state']='biz_q3';
            tg_sendMessage($chat, "3) 3 تا هدف 30 روزه؟");
            break;
        case 'biz_q3':
            $u['biz_auto_form_data']['goals'] = $text; $u['state']='biz_q4';
            tg_sendMessage($chat, "4) چه ابزار/شبکه‌هایی داری؟ (IG, Telegram, Site, ...)", kb([[btn("⏭️ رد کردن","biz_skip_tools")]]));
            break;
        case 'biz_q4':
            $u['biz_auto_form_data']['assets'] = $text; $u['state']='biz_review';
            $d = $u['biz_auto_form_data'];
            $sum = "🔍 خلاصه اطلاعات:\n"
                ."• حوزه: {$d['industry']}\n• مشکل: {$d['pain']}\n• اهداف: {$d['goals']}\n• دارایی‌ها: {$d['assets']}";
            tg_sendMessage($chat, $sum, kb([[btn("✅ تأیید و ارسال به منتورها","biz_confirm")],[btn("✏️ ویرایش از اول","biz_restart")],[btn("⬅️ بازگشت","back_to_menu")]]));
            break;
        case 'biz_review':
            tg_sendMessage($chat, "لطفاً از دکمه‌ها استفاده کن.");
            break;
        default:
            tg_sendMessage($chat, "برای شروع از منو «💡 هوشمندسازی کسب‌وکار» رو بزن.");
            return;
    }
    db_save($db);
}
function biz_confirm_send(&$db, &$u, $chat, $support_chat){
    $d = $u['biz_auto_form_data'] ?? [];
    if (!$d){ tg_sendMessage($chat, "فرمی ثبت نشده."); return; }
    $sum = "💡 درخواست هوشمندسازی جدید\n"
        ."• کاربر: <a href=\"tg://user?id={$chat}\">{$chat}</a>\n"
        ."• حوزه: {$d['industry']}\n• مشکل: {$d['pain']}\n• اهداف: {$d['goals']}\n• دارایی‌ها: {$d['assets']}";
    tg_sendMessage($support_chat, $sum);
    $u['state'] = 'idle'; $u['biz_auto_form_data'] = [];
    db_save($db);
    tg_sendMessage($chat, "✅ ارسال شد. منتورها به‌زودی راهکار می‌دن.", kb([[btn("⬅️ بازگشت به منو","back_to_menu")]]));
}
