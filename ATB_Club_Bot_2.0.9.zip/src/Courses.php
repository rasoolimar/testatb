<?php
require_once __DIR__ . '/Db.php';
require_once __DIR__ . '/Tg.php';

function get_course_by_id($db, $course_id){
    foreach($db['courses'] as $course){
        if($course['id'] == $course_id) return $course;
    }
    return null;
}
function get_user_course_progress(&$db, $user_id, $course_id){
    return $db['user_courses'][$user_id][$course_id] ?? ['status'=>'not_started', 'progress'=> -1];
}
function set_user_course_progress(&$db, $user_id, $course_id, $status, $progress){
    if (!isset($db['user_courses'][$user_id])) $db['user_courses'][$user_id] = [];
    $db['user_courses'][$user_id][$course_id] = ['status'=>$status, 'progress'=>$progress];
    db_save($db);
}

function send_course_step(&$db, $chat_id, $course_id, $step_index) {
    $course = get_course_by_id($db, $course_id);
    if (!$course || !isset($course['content'][$step_index])) {
        tg_sendMessage($chat_id, "مرحله مورد نظر پیدا نشد.", kb([[btn("⬅️ بازگشت به منوی اصلی", "back_to_menu")]]));
        return;
    }
    $step = $course['content'][$step_index];
    $button_text = isset($step['exercise_prompt']) && $step['exercise_prompt'] ? "✅ ویدئو رو دیدم، بریم تمرین" : "✅ دیدم، بریم مرحله بعد";
    $keyboard = kb([[btn($button_text, "seen_step:$course_id:$step_index")],[btn("⬅️ بازگشت به منوی اصلی","back_to_menu")]]);

    if ($step['type'] === 'video') {
        tg_sendVideo($chat_id, $step['file_id'], $step['caption'] ?? "", $keyboard);
    } else {
        tg_sendMessage($chat_id, $step['caption'] ?? "مرحله", $keyboard);
    }
}

function paid_courses_menu($db){
    $rows = [];
    foreach ($db['courses'] as $c){
        if (($c['price'] ?? 0) > 0){
            $rows[] = [ ["text"=>"💼 ".$c['title'], "callback_data"=>"course_view:".$c['id']] ];
        }
    }
    $rows[] = [ ["text"=>"⬅️ بازگشت","callback_data"=>"back_to_menu"] ];
    return json_encode(["inline_keyboard"=>$rows], JSON_UNESCAPED_UNICODE);
}

function course_view_ui($db, $course_id){
    $c = get_course_by_id($db, $course_id);
    if (!$c) return ["این دوره یافت نشد.", kb([[btn("⬅️ بازگشت","paid_courses")]])];
    $txt = "💼 <b>{$c['title']}</b>\n\n".($c['description'] ?? '');
    $kb = kb([
        [btn("🛒 خرید دوره", "course_buy:".$course_id), btn("🎁 هدیه دادن", "course_gift:".$course_id)],
        [btn("🎬 دیدن سرفصل/مراحل", "course_steps:".$course_id)],
        [btn("⬅️ بازگشت","paid_courses")]
    ]);
    return [$txt, $kb];
}

function course_steps_ui($db, $course_id){
    $c = get_course_by_id($db, $course_id);
    if (!$c) return kb([[btn("⬅️ بازگشت","paid_courses")]]);
    $rows = [];
    $steps = $c['content'] ?? [];
    if (empty($steps)) $rows[] = [ ["text"=>"(فعلاً محتوایی ثبت نشده)","callback_data"=>"noop"] ];
    else {
        foreach ($steps as $i=>$s){
            $label = ($i+1).". ".(mb_substr(strip_tags($s['caption'] ?? "مرحله"), 0, 30))."...";
            $rows[] = [ ["text"=>$label, "callback_data"=>"preview_step:{$course_id}:{$i}"] ];
        }
    }
    $rows[] = [ ["text"=>"⬅️ بازگشت","callback_data"=>"course_view:".$course_id] ];
    return json_encode(["inline_keyboard"=>$rows], JSON_UNESCAPED_UNICODE);
}
