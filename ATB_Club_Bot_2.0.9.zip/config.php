<?php
/**
 * ATB Club Bot — v2.0.9 (Modularized)
 * Config & constants
 */
if (!defined('ATB_VERSION')) define('ATB_VERSION', '2.0.9');

function env($key, $default = null) { $v = getenv($key); return ($v === false || $v === null || $v === '') ? $default : $v; }

$BOT_TOKEN              = env("BOT_TOKEN", "8390747300:AAF0V8Z_Ys3qTuWgKCQHLy4zoxvTxDhYKCg");              // توکن ربات
$PRIVATE_CHANNEL_INVITE = env("PRIVATE_CHANNEL_INVITE", "https://t.me/+hUV4tJ7n3b9kMDlk");
$PUBLIC_CHANNEL_ID      = env("PUBLIC_CHANNEL_ID", "@ATB_Club"); // آیدی کانال عمومی
$SUPPORT_CHAT           = env("SUPPORT_CHAT", "-1002827751730"); // آیدی سوپرگروه پشتیبان (منفی با -100)

$VIP_PAYMENT_LINK   = env("VIP_PAYMENT_LINK", "");
$VIP_PRIVATE_INVITE = env("VIP_PRIVATE_INVITE", "https://t.me/+hUV4tJ7n3b9kMDlk");

$ADMIN_PHONE = ["09123079406", "+989150811691"]; // بر اساس شماره‌ها

$DB_FILE  = __DIR__ . "/storage/atb_db.json";     // مسیر جدید دیتابیس
$LOG_FILE = __DIR__ . "/logs/atb_log.txt";

$DEBUG = false;
