<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/src/Handlers.php';

$__exp = getenv('TG_SECRET_TOKEN');
$__got = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';
if ($__exp && !hash_equals($__exp, $__got)) { http_response_code(403); echo "forbidden"; exit; }

$raw = file_get_contents("php://input");
log_it("RAW: ".$raw);
$update = json_decode($raw, true);
http_response_code(200);
echo "OK";
if (is_array($update)) { handle_update($update); }
